  function animation(){
      anime({
          targets: '.polygon',
          points: [
              {value: '0,0 1366,0 402,289 0,768 '},
          ],
          easing: 'easeOutQuad',
          duration: 1200,
          loop: false
      });
  }
